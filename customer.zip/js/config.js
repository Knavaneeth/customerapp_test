
var krms_config ={
	'ApiUrl' : "https://www.cuisine.je/mobileapp/api",
	'cuisineUrl' :"https://www.cuisine.je",
	'DialogDefaultTitle' : "Take Away",
	'pushNotificationSenderid' : "306047836229",
	'facebookAppId' : "124593268247201",
	'APIHasKey' : "db03847be0c7a3fb303f70f30520225c"
};
